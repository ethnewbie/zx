#!/bin/sh
# Start XMRig miner if not already running

# Auto-determine folder of script (so path flexible)
DIR="$(cd "$(dirname "$0")" && pwd)"

# Check if miner is already running
if ! pidof xmrig >/dev/null; then
    echo "Starting XMRig miner..."
    # Run in background, log internal and stdout/stderr
    nohup "$DIR/xmrig" --config "$DIR/config.json" >> "$DIR/xmrig_output.log" 2>&1 &
    echo "Miner started, logging to $DIR/xmrig.log (internal) and $DIR/xmrig_output.log (stdout/stderr)"
else
    echo "Monero miner is already running in the background. Refusing to run another one."
    echo "Run \"killall xmrig\" or \"sudo killall xmrig\" if you want to remove background miner first."
fi